"""
Preset configurations that bundle linters by project type.

Two presets:
  - **webapp**: Full set — architecture, endpoint coverage, test conventions
  - **lib**: Testing conventions only — no architecture or endpoint linters

Each preset defines per-file linters (run on pre-commit with filenames) and
cross-file linters (run on pre-push without filenames).
"""

from __future__ import annotations

import re
from dataclasses import dataclass


@dataclass(frozen=True)
class LinterSpec:
    """
    Metadata for a single linter in a preset.

    module_name: The module under blueprint_linters (e.g. "mock_requires_spec")
    files_pattern: Regex — file must match for linter to run (None = all files)
    exclude_pattern: Regex — file must NOT match (None = no exclusions)
    cross_file: True for linters that scan the whole backend, not individual files
    """

    module_name: str
    files_pattern: str | None = None
    exclude_pattern: str | None = None
    cross_file: bool = False

    def matches_file(self, filepath: str) -> bool:
        """Check if this linter should run on the given file."""
        if self.cross_file:
            return False
        if self.files_pattern and not re.search(self.files_pattern, filepath):
            return False
        if self.exclude_pattern and re.search(self.exclude_pattern, filepath):
            return False
        return True


# ---------------------------------------------------------------------------
# Webapp preset — full architecture enforcement
# ---------------------------------------------------------------------------

WEBAPP_PER_FILE: list[LinterSpec] = [
    LinterSpec("no_pytest_plugins", files_pattern=r"conftest\.py$"),
    LinterSpec("mock_requires_spec", files_pattern=r"tests/"),
    LinterSpec("no_async_integration_tests", files_pattern=r"integration_tests/test_"),
    LinterSpec("enforce_repository_base", files_pattern=r"^backend/"),
    LinterSpec("no_bare_http_errors", files_pattern=r"^backend/"),
    LinterSpec("no_positional_sql_params", files_pattern=r"^backend/"),
    LinterSpec("no_direct_conn_in_endpoints", files_pattern=r"_endpoints\.py$"),
    LinterSpec("no_hardcoded_api_paths", files_pattern=r"^backend/"),
    LinterSpec("no_connection_outside_repo", files_pattern=r"^backend/", exclude_pattern=r"repository\.py$"),
    LinterSpec("types_only_exports", files_pattern=r"exports/types/"),
    LinterSpec("test_support_no_pytest", files_pattern=r"(_factory|_cases|_mock)\.py$"),
    LinterSpec("test_support_naming", files_pattern=r"test_support/"),
    LinterSpec("test_structure_convention", files_pattern=r"tests/unit_tests/.*test_"),
]

WEBAPP_CROSS_FILE: list[LinterSpec] = [
    LinterSpec("every_endpoint_has_test", cross_file=True),
    LinterSpec("every_response_field_asserted", cross_file=True),
]

# ---------------------------------------------------------------------------
# Lib preset — testing conventions only
# ---------------------------------------------------------------------------

LIB_PER_FILE: list[LinterSpec] = [
    LinterSpec("mock_requires_spec", files_pattern=r"tests/"),
    LinterSpec("test_structure_convention", files_pattern=r"tests/unit_tests/.*test_"),
    LinterSpec("no_pytest_plugins", files_pattern=r"conftest\.py$"),
    LinterSpec("test_support_naming", files_pattern=r"test_support/"),
    LinterSpec("test_support_no_pytest", files_pattern=r"(_factory|_cases|_mock)\.py$"),
    LinterSpec("types_only_exports", files_pattern=r"exports/types/"),
]

LIB_CROSS_FILE: list[LinterSpec] = []

# ---------------------------------------------------------------------------
# Preset registry
# ---------------------------------------------------------------------------

PRESETS: dict[str, tuple[list[LinterSpec], list[LinterSpec]]] = {
    "webapp": (WEBAPP_PER_FILE, WEBAPP_CROSS_FILE),
    "lib": (LIB_PER_FILE, LIB_CROSS_FILE),
}
