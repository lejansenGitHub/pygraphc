"""
Tests for all custom linter scripts.
Each test creates temporary Python files and verifies that the check
function correctly identifies violations and passes clean code.
"""

from __future__ import annotations

import ast
from pathlib import Path

from blueprint_linters.ban_direct_sqlalchemy import check_file as check_sqlalchemy
from blueprint_linters.no_async_integration_tests import check_file as check_async_tests
from blueprint_linters.no_db_in_unit_tests import check_file as check_no_db_unit
from blueprint_linters.no_connection_outside_repo import check_file as check_connection_access
from blueprint_linters.enforce_layer_imports import check_file as check_layers
from blueprint_linters.enforce_module_boundaries import check_file as check_boundaries
from blueprint_linters.enforce_repository_base import check_file as check_repo_base
from blueprint_linters.mock_requires_spec import check_file as check_mock_spec
from blueprint_linters.no_cross_app_imports import check_file as check_cross_app
from blueprint_linters.no_deep_commits import check_file as check_commits
from blueprint_linters.no_export_import_in_src import check_file as check_export_in_src
from blueprint_linters.no_fastapi_in_lower_layers import check_file as check_fastapi_layers
from blueprint_linters.no_pytest_plugins import check_file as check_pytest_plugins
from blueprint_linters.no_test_imports_in_prod import check_file as check_test_imports
from blueprint_linters.test_support_naming import check_file as check_naming
from blueprint_linters.test_support_no_pytest import check_file as check_no_pytest
from blueprint_linters.no_bare_http_errors import check_file as check_http_errors
from blueprint_linters.no_direct_conn_in_endpoints import check_file as check_conn_in_endpoints
from blueprint_linters.no_hardcoded_api_paths import check_file as check_api_paths
from blueprint_linters.no_positional_sql_params import check_file as check_sql_params
from blueprint_linters.test_structure_convention import check_file as check_test_structure
from blueprint_linters.types_only_exports import check_file as check_types_only


def _parse(source: str) -> ast.Module:
    return ast.parse(source)


# --- ban_direct_sqlalchemy ---


def test_sqlalchemy_import_in_app_code_rejected() -> None:
    """
    Direct SQLAlchemy import outside base/db is a violation because
    all DB access must go through SQLdataclass.
    """
    source = "from sqlalchemy import text\n"
    errors = check_sqlalchemy(Path("backend/app/orders/src/repo.py"), _parse(source))
    assert len(errors) == 1
    assert "Direct SQLAlchemy import" in errors[0]


def test_sqlalchemy_import_in_base_db_allowed() -> None:
    """
    base/db is the repository infrastructure — it needs raw SQLAlchemy.
    """
    source = "from sqlalchemy import text\n"
    errors = check_sqlalchemy(Path("backend/base/db/src/repository.py"), _parse(source))
    assert errors == []


def test_no_sqlalchemy_import_passes() -> None:
    source = "from backend.base.db.exports.services import ReadRepository\n"
    errors = check_sqlalchemy(Path("backend/app/orders/src/repo.py"), _parse(source))
    assert errors == []


# --- enforce_layer_imports ---


def test_base_importing_service_rejected() -> None:
    """
    base/ cannot import from service/ — import direction is base <- service <- app.
    """
    source = "from backend.service.orders.exports.services import OrderService\n"
    errors = check_layers(Path("backend/base/db/src/util.py"), _parse(source))
    assert len(errors) == 1
    assert "Layer violation" in errors[0]


def test_base_importing_app_rejected() -> None:
    source = "from backend.app.orders.src.endpoints import router\n"
    errors = check_layers(Path("backend/base/config/src/settings.py"), _parse(source))
    assert len(errors) == 1
    assert "Layer violation" in errors[0]


def test_service_importing_base_allowed() -> None:
    source = "from backend.base.db.exports.services import ReadRepository\n"
    errors = check_layers(Path("backend/service/orders/src/repo.py"), _parse(source))
    assert errors == []


def test_app_importing_service_allowed() -> None:
    source = "from backend.service.orders.exports.services import OrderService\n"
    errors = check_layers(Path("backend/app/orders/src/endpoints.py"), _parse(source))
    assert errors == []


def test_service_importing_app_rejected() -> None:
    source = "from backend.app.orders.src.endpoints import router\n"
    errors = check_layers(Path("backend/service/orders/src/service.py"), _parse(source))
    assert len(errors) == 1
    assert "Layer violation" in errors[0]


# --- enforce_module_boundaries ---


def test_cross_module_src_import_rejected() -> None:
    """
    Importing from another module's src/ is a violation — use exports/ instead.
    """
    source = "from backend.service.users.src.repo import UserRepository\n"
    errors = check_boundaries(Path("backend/service/orders/src/service.py"), _parse(source))
    assert len(errors) == 1
    assert "src/" in errors[0]


def test_own_module_src_import_allowed() -> None:
    """
    Importing from your own module's src/ is fine.
    """
    source = "from backend.service.orders.src.repo import OrderRepository\n"
    errors = check_boundaries(Path("backend/service/orders/src/service.py"), _parse(source))
    assert errors == []


# --- no_cross_app_imports ---


def test_app_importing_other_app_rejected() -> None:
    """
    app/orders cannot import from app/users — shared logic belongs in service/.
    """
    source = "from backend.app.users.exports.services import UserService\n"
    errors = check_cross_app(Path("backend/app/orders/src/endpoints.py"), _parse(source))
    assert len(errors) == 1
    assert "Cross-app import" in errors[0]


def test_app_importing_own_code_allowed() -> None:
    source = "from backend.app.orders.src.utils import format_order\n"
    errors = check_cross_app(Path("backend/app/orders/src/endpoints.py"), _parse(source))
    assert errors == []


# --- no_fastapi_in_lower_layers ---


def test_fastapi_in_service_rejected() -> None:
    source = "from fastapi import Depends\n"
    errors = check_fastapi_layers(Path("backend/service/orders/src/service.py"), _parse(source))
    assert len(errors) == 1
    assert "FastAPI import in lower layer" in errors[0]


def test_fastapi_in_base_rejected() -> None:
    source = "import fastapi\n"
    errors = check_fastapi_layers(Path("backend/base/config/src/settings.py"), _parse(source))
    assert len(errors) == 1


def test_fastapi_in_app_allowed() -> None:
    source = "from fastapi import APIRouter, Depends\n"
    errors = check_fastapi_layers(Path("backend/app/orders/src/endpoints.py"), _parse(source))
    assert errors == []


# --- no_deep_commits ---


def test_commit_in_service_rejected() -> None:
    """
    .commit() in service layer is a violation — commits belong in endpoints/tasks.
    """
    source = "repo.commit()\n"
    errors = check_commits(Path("backend/service/orders/src/service.py"), _parse(source))
    assert len(errors) == 1
    assert ".commit()" in errors[0]


def test_commit_in_workflow_rejected() -> None:
    source = "repo.commit()\n"
    errors = check_commits(Path("backend/app/orders/src/workflow.py"), _parse(source))
    assert len(errors) == 1


def test_commit_in_endpoints_allowed() -> None:
    source = "repo.commit()\n"
    errors = check_commits(Path("backend/app/orders/src/endpoints.py"), _parse(source))
    assert errors == []


def test_commit_in_tasks_allowed() -> None:
    source = "repo.commit()\n"
    errors = check_commits(Path("backend/app/orders/src/tasks.py"), _parse(source))
    assert errors == []


def test_commit_in_test_allowed() -> None:
    source = "repo.commit()\n"
    errors = check_commits(Path("backend/service/orders/tests/integration_tests/test_order.py"), _parse(source))
    assert errors == []


# --- no_test_imports_in_prod ---


def test_prod_importing_tests_rejected() -> None:
    source = "from backend.service.orders.tests.test_support.order_factory import create_order\n"
    errors = check_test_imports(Path("backend/service/orders/src/service.py"), _parse(source))
    assert len(errors) == 1
    assert "Production code imports from .tests" in errors[0]


def test_test_file_importing_tests_allowed() -> None:
    source = "from backend.service.orders.tests.test_support.order_factory import create_order\n"
    errors = check_test_imports(Path("backend/service/orders/tests/unit_tests/test_order.py"), _parse(source))
    assert errors == []


# --- types_only_exports ---


def test_function_in_types_export_rejected() -> None:
    """
    exports/types/ files may not contain function definitions.
    """
    source = "def create_order(): return None\n"
    errors = check_types_only(Path("backend/service/orders/exports/types/order_types.py"), _parse(source))
    assert len(errors) == 1
    assert "Function definition in exports/types/" in errors[0]


def test_dataclass_in_types_export_allowed() -> None:
    source = """
from dataclasses import dataclass

@dataclass(frozen=True)
class Order:
    order_id: int
    name: str
"""
    errors = check_types_only(Path("backend/service/orders/exports/types/order_types.py"), _parse(source))
    assert errors == []


def test_protocol_stub_in_types_export_allowed() -> None:
    source = """
from typing import Protocol

class OrderProtocol(Protocol):
    def get_order(self) -> None: ...
"""
    errors = check_types_only(Path("backend/service/orders/exports/types/protocols.py"), _parse(source))
    assert errors == []


def test_method_with_body_in_types_export_rejected() -> None:
    source = """
class OrderHelper:
    def compute(self) -> int:
        return 42
"""
    errors = check_types_only(Path("backend/service/orders/exports/types/helpers.py"), _parse(source))
    assert len(errors) == 1
    assert "Method with implementation" in errors[0]


# --- test_support_no_pytest ---


def test_pytest_in_factory_rejected() -> None:
    source = "import pytest\n"
    errors = check_no_pytest(Path("backend/service/orders/tests/test_support/order_factory.py"), _parse(source))
    assert len(errors) == 1
    assert "pytest import" in errors[0]


def test_pytest_in_fixtures_allowed() -> None:
    source = "import pytest\n"
    errors = check_no_pytest(Path("backend/service/orders/tests/test_support/order_fixtures.py"), _parse(source))
    assert errors == []


def test_no_pytest_in_cases_passes() -> None:
    source = "from dataclasses import dataclass\n"
    errors = check_no_pytest(Path("backend/service/orders/tests/test_support/order_cases.py"), _parse(source))
    assert errors == []


# --- no_pytest_plugins ---


def test_pytest_plugins_in_conftest_rejected() -> None:
    source = 'pytest_plugins = ["backend.orders.tests.fixtures"]\n'
    errors = check_pytest_plugins(Path("backend/service/orders/tests/conftest.py"), _parse(source))
    assert len(errors) == 1
    assert "pytest_plugins" in errors[0]


def test_conftest_without_pytest_plugins_passes() -> None:
    source = "from backend.orders.tests.test_support.fixtures import my_fixture\n_imported = [my_fixture]\n"
    errors = check_pytest_plugins(Path("backend/service/orders/tests/conftest.py"), _parse(source))
    assert errors == []


def test_non_conftest_with_pytest_plugins_ignored() -> None:
    source = 'pytest_plugins = ["something"]\n'
    errors = check_pytest_plugins(Path("backend/service/orders/tests/test_order.py"), _parse(source))
    assert errors == []


# --- test_support_naming ---


def test_bad_name_in_test_support_rejected() -> None:
    errors = check_naming(Path("backend/service/orders/tests/test_support/helpers.py"))
    assert len(errors) == 1
    assert "naming convention" in errors[0]


def test_valid_factory_name_passes() -> None:
    errors = check_naming(Path("backend/service/orders/tests/test_support/order_factory.py"))
    assert errors == []


def test_valid_fixtures_name_passes() -> None:
    errors = check_naming(Path("backend/service/orders/tests/test_support/order_fixtures.py"))
    assert errors == []


def test_init_in_test_support_passes() -> None:
    errors = check_naming(Path("backend/service/orders/tests/test_support/__init__.py"))
    assert errors == []


def test_file_in_valid_subdirectory_passes() -> None:
    errors = check_naming(Path("backend/service/orders/tests/test_support/factories/order.py"))
    assert errors == []


# --- no_export_import_in_src ---


def test_src_importing_own_exports_rejected() -> None:
    """
    src/ must not import from its own exports/ to avoid cycles.
    """
    source = "from backend.service.orders.exports.services import OrderService\n"
    errors = check_export_in_src(Path("backend/service/orders/src/service.py"), _parse(source))
    assert len(errors) == 1
    assert "src/ imports from own exports/" in errors[0]


def test_src_importing_external_passes() -> None:
    source = "from backend.base.db.exports.services import ReadRepository\n"
    errors = check_export_in_src(Path("backend/service/orders/src/service.py"), _parse(source))
    assert errors == []


# --- mock_requires_spec ---


def test_magicmock_without_spec_rejected() -> None:
    source = "mock = MagicMock()\n"
    errors = check_mock_spec(Path("backend/service/orders/tests/unit_tests/test_order.py"), _parse(source))
    assert len(errors) == 1
    assert "without spec=" in errors[0]


def test_magicmock_with_spec_passes() -> None:
    source = "mock = MagicMock(spec=OrderService)\n"
    errors = check_mock_spec(Path("backend/service/orders/tests/unit_tests/test_order.py"), _parse(source))
    assert errors == []


def test_mocker_magicmock_without_spec_rejected() -> None:
    source = "mock = mocker.MagicMock()\n"
    errors = check_mock_spec(Path("backend/service/orders/tests/unit_tests/test_order.py"), _parse(source))
    assert len(errors) == 1


def test_mocker_magicmock_with_spec_passes() -> None:
    source = "mock = mocker.MagicMock(spec=OrderService)\n"
    errors = check_mock_spec(Path("backend/service/orders/tests/unit_tests/test_order.py"), _parse(source))
    assert errors == []


# --- enforce_repository_base ---


def test_repository_without_base_rejected() -> None:
    source = """
class OrderRepository:
    pass
"""
    errors = check_repo_base(Path("backend/service/orders/src/repo.py"), _parse(source))
    assert len(errors) == 1
    assert "does not extend" in errors[0]


def test_repository_with_read_base_passes() -> None:
    source = """
class OrderReadRepository(ReadRepository):
    pass
"""
    errors = check_repo_base(Path("backend/service/orders/src/repo.py"), _parse(source))
    assert errors == []


def test_repository_with_write_base_passes() -> None:
    source = """
class OrderWriteRepository(WriteRepository):
    pass
"""
    errors = check_repo_base(Path("backend/service/orders/src/repo.py"), _parse(source))
    assert errors == []


def test_non_repository_class_ignored() -> None:
    source = """
class OrderService:
    pass
"""
    errors = check_repo_base(Path("backend/service/orders/src/service.py"), _parse(source))
    assert errors == []


def test_base_repository_module_itself_skipped() -> None:
    source = """
class ReadRepository:
    pass
class WriteRepository(ReadRepository):
    pass
"""
    errors = check_repo_base(Path("backend/base/db/src/repository.py"), _parse(source))
    assert errors == []


# --- no_connection_outside_repo ---


def test_connection_access_in_endpoint_rejected() -> None:
    """
    _connection is private to repository classes. Endpoints must use
    repository methods, not access the connection directly.
    """
    source = "result = repo._connection.execute('SELECT 1')\n"
    errors = check_connection_access(Path("backend/app/orders/src/endpoints.py"), _parse(source))
    assert len(errors) == 1
    assert "_connection access outside repository" in errors[0]


def test_connection_access_in_service_rejected() -> None:
    source = "result = repo._connection.fetchrow('SELECT 1')\n"
    errors = check_connection_access(Path("backend/service/orders/src/service.py"), _parse(source))
    assert len(errors) == 1


def test_connection_access_in_repository_allowed() -> None:
    source = "result = self._connection.execute('SELECT 1')\n"
    errors = check_connection_access(Path("backend/service/orders/src/repository.py"), _parse(source))
    assert errors == []


def test_connection_access_in_prefixed_repository_allowed() -> None:
    source = "result = self._connection.fetchrow('SELECT 1')\n"
    errors = check_connection_access(Path("backend/service/orders/src/order_repository.py"), _parse(source))
    assert errors == []


# --- no_async_integration_tests ---


def test_async_test_in_integration_tests_rejected() -> None:
    """
    Integration tests use sync TestClient. Async adds ~200ms
    framework overhead per test and causes event loop issues.
    """
    source = "async def test_create_order(client): pass\n"
    errors = check_async_tests(
        Path("backend/app/orders/tests/integration_tests/test_orders.py"), _parse(source)
    )
    assert len(errors) == 1
    assert "Async test function" in errors[0]


def test_sync_test_in_integration_tests_allowed() -> None:
    source = "def test_create_order(client): pass\n"
    errors = check_async_tests(
        Path("backend/app/orders/tests/integration_tests/test_orders.py"), _parse(source)
    )
    assert errors == []


def test_async_test_in_e2e_tests_allowed() -> None:
    """E2E tests (Playwright) are naturally async."""
    source = "async def test_login_flow(page): pass\n"
    errors = check_async_tests(
        Path("backend/app/orders/tests/e2e_tests/test_login.py"), _parse(source)
    )
    assert errors == []


def test_async_helper_in_integration_tests_allowed() -> None:
    """Only test_ functions are checked, not helpers."""
    source = "async def setup_data(): pass\n"
    errors = check_async_tests(
        Path("backend/app/orders/tests/integration_tests/test_orders.py"), _parse(source)
    )
    assert errors == []


# --- no_db_in_unit_tests ---


def test_psycopg_import_in_unit_test_rejected() -> None:
    source = "import psycopg\n"
    errors = check_no_db_unit(Path("backend/service/orders/tests/unit_tests/test_service.py"), _parse(source))
    assert len(errors) == 1
    assert "DB import in unit test" in errors[0]


def test_asyncpg_import_in_unit_test_rejected() -> None:
    source = "import asyncpg\n"
    errors = check_no_db_unit(Path("backend/service/orders/tests/unit_tests/test_service.py"), _parse(source))
    assert len(errors) == 1


def test_get_db_import_in_unit_test_rejected() -> None:
    source = "from backend.base.db.src.database import get_db\n"
    errors = check_no_db_unit(Path("backend/service/orders/tests/unit_tests/test_service.py"), _parse(source))
    assert len(errors) == 1
    assert "get_db" in errors[0]


def test_fastapi_testclient_in_unit_test_allowed() -> None:
    """TestClient is fine for endpoint format/conversion tests with mocked deps."""
    source = "from fastapi.testclient import TestClient\n"
    errors = check_no_db_unit(Path("backend/app/orders/tests/unit_tests/test_endpoints.py"), _parse(source))
    assert errors == []


def test_psycopg_in_integration_test_allowed() -> None:
    source = "import psycopg\n"
    errors = check_no_db_unit(Path("backend/app/orders/tests/integration_tests/test_orders.py"), _parse(source))
    assert errors == []


def test_psycopg_in_component_test_allowed() -> None:
    source = "import psycopg\n"
    errors = check_no_db_unit(Path("backend/app/orders/tests/component_tests/test_repo.py"), _parse(source))
    assert errors == []


# --- test_structure_convention ---


def test_simple_test_missing_docstring_rejected() -> None:
    """
    Simple tests must have a docstring explaining WHY the expected result is correct.
    """
    source = """
def test_foo():
    result = 1 + 1
    assert result == 2
"""
    errors = check_test_structure(Path("backend/service/orders/tests/unit_tests/test_math.py"), _parse(source), source_text=source)
    assert len(errors) >= 1
    assert "missing docstring" in errors[0]


def test_simple_test_with_docstring_passes() -> None:
    """
    A simple test with a docstring should pass.
    """
    source = '''
def test_foo():
    """1 + 1 is 2 because addition is commutative."""
    result = 1 + 1
    assert result == 2
'''
    errors = check_test_structure(Path("backend/service/orders/tests/unit_tests/test_math.py"), _parse(source), source_text=source)
    assert errors == []


def test_nontrivial_test_missing_assert_section_rejected() -> None:
    """
    Non-trivial tests (15+ lines) must have at least an Assert section marker.
    """
    source = '''
def test_complex():
    """Some explanation."""
    a = 1
    b = 2
    c = 3
    d = 4
    e = 5
    f = 6
    g = 7
    h = 8
    i = 9
    j = 10
    k = 11
    l = 12
    m = 13
    n = 14
    assert a + b + c + d + e + f + g + h + i + j + k + l + m + n == 105
'''
    errors = check_test_structure(Path("backend/service/orders/tests/unit_tests/test_math.py"), _parse(source), source_text=source)
    assert any("Assert" in error for error in errors)


def test_expected_before_execute_enforced() -> None:
    """
    If both Expected and Execute sections exist, Expected must come first.
    """
    source = '''
def test_ordering():
    """Test explanation."""
    # --- Execute ---
    result = compute()
    # --- Expected ---
    expected = 42
    # --- Assert ---
    assert result == expected
'''
    errors = check_test_structure(Path("backend/service/orders/tests/unit_tests/test_order.py"), _parse(source), source_text=source)
    assert any("Expected" in error and "after" in error for error in errors)


def test_correct_section_order_passes() -> None:
    """
    Expected before Execute is the correct order.
    """
    source = '''
def test_ordering():
    """Test explanation."""
    # --- Input ---
    x = 1
    # --- Expected ---
    expected = 2
    # --- Execute ---
    result = x + 1
    # --- Assert ---
    assert result == expected
'''
    errors = check_test_structure(Path("backend/service/orders/tests/unit_tests/test_order.py"), _parse(source), source_text=source)
    assert errors == []


def test_parametrized_test_few_cases_rejected() -> None:
    """
    Parametrized tests with fewer than 4 cases should use separate test functions.
    """
    source = """
import pytest

@pytest.mark.parametrize("x,expected", [(1, 2), (2, 3)])
def test_increment(x, expected):
    assert x + 1 == expected
"""
    errors = check_test_structure(Path("backend/service/orders/tests/unit_tests/test_math.py"), _parse(source), source_text=source)
    assert len(errors) >= 1
    assert "2 cases" in errors[0]


def test_parametrized_test_enough_cases_passes() -> None:
    """
    Parametrized tests with 4+ cases are fine.
    """
    source = """
import pytest

@pytest.mark.parametrize("x,expected", [(1, 2), (2, 3), (0, 1), (-1, 0)])
def test_increment(x, expected):
    assert x + 1 == expected
"""
    errors = check_test_structure(Path("backend/service/orders/tests/unit_tests/test_math.py"), _parse(source), source_text=source)
    assert errors == []


def test_non_test_file_ignored() -> None:
    """
    Files not named test_*.py should be ignored entirely.
    """
    source = """
def test_something():
    pass
"""
    errors = check_test_structure(Path("backend/service/orders/src/utils.py"), _parse(source), source_text=source)
    assert errors == []


# --- every_endpoint_has_test ---


def test_endpoint_has_test_catches_missing() -> None:
    """
    Validates the linter can parse endpoint decorators and find URL constants.
    Full cross-file testing is done via running the linter on the real codebase.
    """
    from blueprint_linters.every_endpoint_has_test import _collect_endpoint_url_constants
    import tempfile
    import os

    with tempfile.TemporaryDirectory() as tmp:
        endpoint_file = Path(tmp) / "order_endpoints.py"
        endpoint_file.write_text("""
from fastapi import APIRouter
router = APIRouter()

@router.get(ORDERS)
def list_orders():
    pass

@router.post(ORDERS)
def create_order():
    pass
""")
        urls = _collect_endpoint_url_constants(Path(tmp))
        assert "ORDERS" in urls


# --- every_response_field_asserted ---


def test_response_field_linter_detects_model_fields() -> None:
    """
    Validates the linter correctly extracts Pydantic model field names
    including those with defaults.
    """
    from blueprint_linters.every_response_field_asserted import _collect_model_fields, FieldInfo
    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        models_file = Path(tmp) / "models.py"
        models_file.write_text("""
from pydantic import BaseModel

class OrderOut(BaseModel):
    id: int
    name: str
    status: str = "pending"
    items: list = []
""")
        fields = _collect_model_fields(Path(tmp))
        assert "OrderOut" in fields
        field_names = {f.name for f in fields["OrderOut"]}
        assert field_names == {"id", "name", "status", "items"}

        # Check defaults are tracked
        status_field = next(f for f in fields["OrderOut"] if f.name == "status")
        assert status_field.has_default is True
        assert status_field.default_value == "pending"

        items_field = next(f for f in fields["OrderOut"] if f.name == "items")
        assert items_field.has_default is True


def test_response_field_linter_extracts_dict_keys() -> None:
    """
    Validates the linter can extract string keys from dict literal returns.
    """
    from blueprint_linters.every_response_field_asserted import _extract_dict_keys_from_return, FieldInfo

    source = '''
def get_status():
    return {"status": "ok", "uptime": 123}
'''
    tree = _parse(source)
    func = tree.body[0]
    fields = _extract_dict_keys_from_return(func)
    field_names = {f.name for f in fields}
    assert field_names == {"status", "uptime"}


# --- no_bare_http_errors ---


def test_http_exception_in_endpoint_rejected() -> None:
    """
    raise HTTPException in backend code is a violation — use domain exceptions.
    """
    source = "raise HTTPException(status_code=404, detail='Not found')\n"
    errors = check_http_errors(Path("backend/app/api/src/endpoints.py"), _parse(source))
    assert len(errors) == 1
    assert "HTTPException" in errors[0]
    assert "domain exceptions" in errors[0]


def test_http_exception_in_test_allowed() -> None:
    """
    Tests may reference HTTPException (e.g. testing error responses).
    """
    source = "raise HTTPException(status_code=400)\n"
    errors = check_http_errors(Path("backend/app/api/tests/integration_tests/test_foo.py"), _parse(source))
    assert errors == []


def test_domain_exception_passes() -> None:
    source = "raise NotFoundError('Deck not found')\n"
    errors = check_http_errors(Path("backend/app/api/src/endpoints.py"), _parse(source))
    assert errors == []


def test_http_exception_in_non_backend_ignored() -> None:
    source = "raise HTTPException(status_code=500)\n"
    errors = check_http_errors(Path("scripts/migrate.py"), _parse(source))
    assert errors == []


# --- no_positional_sql_params ---


def test_positional_params_in_sql_rejected() -> None:
    """
    Positional %s in SQL strings is banned — use %(name)s with dicts.
    """
    source = 'x = "SELECT * FROM users WHERE id = %s"\n'
    errors = check_sql_params(Path("backend/service/auth/src/repo.py"), _parse(source))
    assert len(errors) == 1
    assert "%(name)s" in errors[0]


def test_named_params_allowed() -> None:
    source = 'x = "SELECT * FROM users WHERE id = %(user_id)s"\n'
    errors = check_sql_params(Path("backend/service/auth/src/repo.py"), _parse(source))
    assert errors == []


def test_non_sql_string_with_percent_s_ignored() -> None:
    """
    %s in non-SQL strings (e.g. log messages) should not trigger.
    """
    source = 'x = "User %s not found"\n'
    errors = check_sql_params(Path("backend/service/auth/src/repo.py"), _parse(source))
    assert errors == []


def test_positional_params_in_test_allowed() -> None:
    source = 'x = "SELECT * FROM users WHERE id = %s"\n'
    errors = check_sql_params(Path("backend/app/api/tests/test_foo.py"), _parse(source))
    assert errors == []


# --- no_direct_conn_in_endpoints ---


def test_get_connection_in_endpoint_rejected() -> None:
    """
    Endpoints must use repo Depends, not raw get_connection.
    """
    source = "from backend.base.db.src.database import get_connection\n"
    errors = check_conn_in_endpoints(Path("backend/app/api/src/deck_endpoints.py"), _parse(source))
    assert len(errors) == 1
    assert "repo Depends" in errors[0]


def test_get_connection_in_task_allowed() -> None:
    """
    Celery tasks create connections manually — not a violation.
    """
    source = "from backend.base.db.src.database import get_connection\n"
    errors = check_conn_in_endpoints(Path("backend/app/api/src/sync_tasks.py"), _parse(source))
    assert errors == []


def test_get_connection_in_test_allowed() -> None:
    source = "from backend.base.db.src.database import get_connection\n"
    errors = check_conn_in_endpoints(Path("backend/app/api/tests/conftest.py"), _parse(source))
    assert errors == []


def test_repo_depends_in_endpoint_passes() -> None:
    source = "from backend.app.api.src.dependencies import get_deck_read_repo\n"
    errors = check_conn_in_endpoints(Path("backend/app/api/src/deck_endpoints.py"), _parse(source))
    assert errors == []


# --- no_hardcoded_api_paths ---


def test_hardcoded_api_path_rejected() -> None:
    source = 'resp = client.get("/api/decks")\n'
    errors = check_api_paths(Path("backend/app/api/src/deck_endpoints.py"), _parse(source))
    assert len(errors) == 1
    assert "urls" in errors[0]


def test_url_constant_passes() -> None:
    source = "resp = client.get(DECKS)\n"
    errors = check_api_paths(Path("backend/app/api/src/deck_endpoints.py"), _parse(source))
    assert errors == []


def test_urls_py_itself_exempt() -> None:
    source = 'DECKS = "/api/decks"\n'
    errors = check_api_paths(Path("backend/app/api/src/urls.py"), _parse(source))
    assert errors == []


def test_non_backend_exempt() -> None:
    source = 'resp = client.get("/api/decks")\n'
    errors = check_api_paths(Path("scripts/test.py"), _parse(source))
    assert errors == []
