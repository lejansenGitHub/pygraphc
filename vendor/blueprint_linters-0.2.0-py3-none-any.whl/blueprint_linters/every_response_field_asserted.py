#!/usr/bin/env python3
"""
Every field in an endpoint's response must be asserted in at least one test.

Two checks:

1. **Field presence:** Every response field must appear as a subscript key
   (["field"]) in at least one test file that imports the endpoint's URL constant.

2. **Default-value coverage:** For Pydantic fields with defaults (e.g.
   `status: str = "draft"`), at least one test must assert a non-default value.
   Otherwise a bug that always returns the default would pass silently.

This catches the class of bugs where an endpoint returns a field that no test
ever inspects — like rubies_updated_at being silently wrong for months because
every test only checked the rubies balance.
"""

from __future__ import annotations

import ast
import sys
from dataclasses import dataclass
from pathlib import Path


def _parse_file(filepath: Path) -> ast.Module | None:
    """Parse a Python file, returning None on failure."""
    try:
        source = filepath.read_text(encoding="utf-8")
        return ast.parse(source, filename=str(filepath))
    except (SyntaxError, FileNotFoundError, PermissionError):
        return None


@dataclass(frozen=True)
class FieldInfo:
    """Metadata about a response field."""

    name: str
    default_value: object | None = None
    has_default: bool = False


# ---------------------------------------------------------------------------
# Step 1: Collect Pydantic model fields (with defaults)
# ---------------------------------------------------------------------------

# Sentinel for "no default"
_NO_DEFAULT = object()


def _extract_constant(node: ast.expr) -> object:
    """Extract a Python constant from an AST node. Returns _NO_DEFAULT if not a simple constant."""
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.List) and not node.elts:
        return []
    if isinstance(node, ast.Dict) and not node.keys:
        return {}
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub) and isinstance(node.operand, ast.Constant):
        return -node.operand.value
    return _NO_DEFAULT


def _collect_model_fields(backend_path: Path) -> dict[str, list[FieldInfo]]:
    """
    Parse Pydantic model files to build {ClassName: [FieldInfo, ...]}.
    Tracks field names and their default values (if any).
    """
    model_fields: dict[str, list[FieldInfo]] = {}

    for filepath in backend_path.rglob("models.py"):
        tree = _parse_file(filepath)
        if tree is None:
            continue

        for node in ast.walk(tree):
            if not isinstance(node, ast.ClassDef):
                continue
            if not any(
                (isinstance(base, ast.Name) and base.id == "BaseModel")
                for base in node.bases
            ):
                continue

            fields: list[FieldInfo] = []
            for item in node.body:
                if not isinstance(item, ast.AnnAssign) or not isinstance(item.target, ast.Name):
                    continue
                field_name = item.target.id
                if item.value is None:
                    fields.append(FieldInfo(name=field_name))
                else:
                    # Has a default — extract it if it's a simple constant
                    default = _extract_constant(item.value)
                    if default is _NO_DEFAULT and isinstance(item.value, ast.Call):
                        # Could be Field(default=...) or complex expression
                        for keyword in item.value.keywords:
                                if keyword.arg == "default":
                                    default = _extract_constant(keyword.value)
                                    break
                    if default is not _NO_DEFAULT:
                        fields.append(FieldInfo(name=field_name, default_value=default, has_default=True))
                    else:
                        fields.append(FieldInfo(name=field_name, has_default=True))

            if fields:
                model_fields[node.name] = fields

    return model_fields


# ---------------------------------------------------------------------------
# Step 2: Map endpoints to their response fields
# ---------------------------------------------------------------------------


def _extract_model_name_from_annotation(annotation: ast.expr) -> str | None:
    """
    Extract the model class name from a response_model annotation.
    Handles: ModelName, list[ModelName], list[ModelName] | None.
    """
    if isinstance(annotation, ast.Name):
        return annotation.id
    if isinstance(annotation, ast.Subscript) and isinstance(annotation.slice, ast.Name):
        return annotation.slice.id
    if isinstance(annotation, ast.BinOp):
        return _extract_model_name_from_annotation(annotation.left)
    return None


def _extract_dict_keys_from_return(func_node: ast.FunctionDef) -> list[FieldInfo]:
    """
    Find string keys in dict literal return statements.
    Dict returns have no defaults — every field should be asserted.
    """
    fields: list[FieldInfo] = []
    seen: set[str] = set()
    for node in ast.walk(func_node):
        if not isinstance(node, ast.Return) or node.value is None:
            continue
        if isinstance(node.value, ast.Dict):
            for key in node.value.keys:
                if isinstance(key, ast.Constant) and isinstance(key.value, str) and key.value not in seen:
                    fields.append(FieldInfo(name=key.value))
                    seen.add(key.value)
    return fields


def _collect_endpoint_response_fields(
    backend_path: Path,
    model_fields: dict[str, list[FieldInfo]],
) -> dict[str, list[FieldInfo]]:
    """
    For each endpoint, map URL_CONSTANT → [FieldInfo, ...].
    """
    endpoint_fields: dict[str, list[FieldInfo]] = {}

    for filepath in backend_path.rglob("*_endpoints.py"):
        tree = _parse_file(filepath)
        if tree is None:
            continue

        for node in ast.walk(tree):
            if not isinstance(node, ast.FunctionDef):
                continue

            url_constant = None
            response_model_name = None

            for decorator in node.decorator_list:
                if not isinstance(decorator, ast.Call):
                    continue
                func = decorator.func
                if not isinstance(func, ast.Attribute):
                    continue
                if func.attr not in ("get", "post", "patch", "delete", "put"):
                    continue
                if not decorator.args:
                    continue
                first_arg = decorator.args[0]
                if isinstance(first_arg, ast.Name):
                    url_constant = first_arg.id
                for keyword in decorator.keywords:
                    if keyword.arg == "response_model":
                        response_model_name = _extract_model_name_from_annotation(keyword.value)

            if url_constant is None:
                continue

            if response_model_name and response_model_name in model_fields:
                endpoint_fields[url_constant] = model_fields[response_model_name]
            else:
                fields = _extract_dict_keys_from_return(node)
                if fields:
                    endpoint_fields[url_constant] = fields

    return endpoint_fields


# ---------------------------------------------------------------------------
# Step 3: Collect asserted fields and values per URL constant in tests
# ---------------------------------------------------------------------------


def _collect_test_assertions(backend_path: Path) -> dict[str, dict[str, set[object]]]:
    """
    For each URL constant imported in test files, collect all string keys
    accessed via subscript (["field_name"]) and the values they're compared
    against in assertions.

    Returns {URL_CONSTANT: {field_name: {asserted_values}}}.
    Values that can't be statically determined are represented by _NO_DEFAULT sentinel.
    """
    url_to_field_values: dict[str, dict[str, set[object]]] = {}

    for filepath in backend_path.rglob("test_*.py"):
        tree = _parse_file(filepath)
        if tree is None:
            continue

        imported_urls: set[str] = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module and "urls" in node.module:
                for alias in node.names:
                    imported_urls.add(alias.name)

        if not imported_urls:
            continue

        # Collect field accesses and asserted values
        field_values: dict[str, set[object]] = {}

        for node in ast.walk(tree):
            # Pattern: x["field_name"]
            if isinstance(node, ast.Subscript) and isinstance(node.slice, ast.Constant) and isinstance(
                node.slice.value, str
            ):
                field_name = node.slice.value
                if field_name not in field_values:
                    field_values[field_name] = set()
                # Mark as accessed (value unknown)
                field_values[field_name].add(_NO_DEFAULT)

            # Pattern: assert x["field"] == value
            if isinstance(node, ast.Assert) and isinstance(node.test, ast.Compare):
                left = node.test.left
                if (
                    isinstance(left, ast.Subscript)
                    and isinstance(left.slice, ast.Constant)
                    and isinstance(left.slice.value, str)
                ):
                    field_name = left.slice.value
                    if field_name not in field_values:
                        field_values[field_name] = set()
                    for comparator in node.test.comparators:
                        val = _extract_constant(comparator)
                        # Convert unhashable types for set storage
                        if isinstance(val, list):
                            val = tuple(val)
                        elif isinstance(val, dict):
                            val = tuple(sorted(val.items()))
                        field_values[field_name].add(val)

        for url_name in imported_urls:
            if url_name not in url_to_field_values:
                url_to_field_values[url_name] = {}
            for field_name, values in field_values.items():
                if field_name not in url_to_field_values[url_name]:
                    url_to_field_values[url_name][field_name] = set()
                url_to_field_values[url_name][field_name] |= values

    return url_to_field_values


# ---------------------------------------------------------------------------
# Step 4: Compare and report
# ---------------------------------------------------------------------------


def check_all(backend_path: Path) -> list[str]:
    """
    Check that every response field is asserted, and that fields with defaults
    are asserted with at least one non-default value.
    """
    model_fields = _collect_model_fields(backend_path)
    endpoint_fields = _collect_endpoint_response_fields(backend_path, model_fields)
    test_assertions = _collect_test_assertions(backend_path)

    errors: list[str] = []
    for url_constant, fields in sorted(endpoint_fields.items()):
        test_data = test_assertions.get(url_constant, {})

        # Check 1: every field accessed in at least one test
        untested = [field.name for field in fields if field.name not in test_data]
        if untested:
            fields_str = ", ".join(sorted(untested))
            errors.append(
                f"Endpoint {url_constant}: response fields not asserted in any test: {fields_str}"
            )

        # Check 2: fields with defaults must have at least one non-default assertion
        for field in fields:
            if not field.has_default or field.default_value is None:
                continue
            if field.name not in test_data:
                continue  # Already caught by check 1

            asserted_values = test_data[field.name]
            # Remove the "accessed but value unknown" sentinel and the default itself
            concrete_values = {v for v in asserted_values if v is not _NO_DEFAULT}
            if not concrete_values:
                # Field is accessed but never compared to a specific value — could go either way
                continue
            # Check if all concrete assertions are just the default
            # Normalize default for comparison (lists become tuples in test assertions)
            normalized_default = field.default_value
            if isinstance(normalized_default, list):
                normalized_default = tuple(normalized_default)
            elif isinstance(normalized_default, dict):
                normalized_default = tuple(sorted(normalized_default.items()))
            non_default_values = {v for v in concrete_values if v != normalized_default}
            if not non_default_values:
                errors.append(
                    f"Endpoint {url_constant}: field '{field.name}' only asserted with "
                    f"default value {field.default_value!r} — add a test with a non-default value"
                )

    return errors


def main() -> None:
    backend = Path("backend")
    errors = check_all(backend)
    for error in errors:
        print(error)  # noqa: T201  # linter output
    sys.exit(1 if errors else 0)


if __name__ == "__main__":
    main()
