#!/usr/bin/env python3
"""
Every write endpoint must have at least one test that verifies persistence.

A write endpoint is a @router.post/patch/put/delete handler that injects a
WriteRepository dependency (i.e. it actually writes to the database).
Endpoints without a write repo (e.g. login, preview) are skipped.

A persistence test is a test function that calls the write method AND then
calls .get( to re-fetch and verify the change was actually committed.
Helper functions (e.g. ``_create_archetype``, ``_get_archetype_ids``) are
resolved one level deep so that common test patterns are recognised.

Without this, tests can pass by checking only the response while the
database silently rolls back (e.g. missing commit()).
"""

from __future__ import annotations

import ast
import sys
from pathlib import Path

_WRITE_METHODS = {"post", "patch", "put", "delete"}


def _has_write_repo_param(func_node: ast.FunctionDef) -> bool:
    """
    Check if a function has a parameter whose type annotation contains
    'WriteRepository' (e.g. write_repo: DeckWriteRepository = Depends(...)).
    """
    for arg in func_node.args.args:
        annotation = arg.annotation
        if annotation is None:
            continue
        if isinstance(annotation, ast.Name) and "WriteRepository" in annotation.id:
            return True
        if isinstance(annotation, ast.Attribute) and "WriteRepository" in annotation.attr:
            return True
    return False


def _collect_write_endpoint_urls(backend_path: Path) -> dict[str, str]:
    """
    Find URL constants used in write endpoint decorators that inject a
    WriteRepository. Returns {constant_name: filepath_and_line}.
    """
    write_urls: dict[str, str] = {}

    for filepath in backend_path.rglob("*_endpoints.py"):
        try:
            source = filepath.read_text(encoding="utf-8")
            tree = ast.parse(source, filename=str(filepath))
        except SyntaxError:
            continue

        for node in ast.walk(tree):
            if not isinstance(node, ast.FunctionDef):
                continue
            if not _has_write_repo_param(node):
                continue
            for decorator in node.decorator_list:
                if not isinstance(decorator, ast.Call):
                    continue
                func = decorator.func
                if not isinstance(func, ast.Attribute):
                    continue
                if func.attr not in _WRITE_METHODS:
                    continue
                if not decorator.args:
                    continue
                first_arg = decorator.args[0]
                if isinstance(first_arg, ast.Name):
                    write_urls[first_arg.id] = f"{filepath}:{node.lineno}"

    return write_urls


def _build_helper_map(tree: ast.Module) -> dict[str, ast.FunctionDef]:
    """
    Build a map of helper function names to their AST nodes.
    Helpers are non-test functions defined at the module level.
    """
    helpers: dict[str, ast.FunctionDef] = {}
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.FunctionDef) and not node.name.startswith("test_"):
            helpers[node.name] = node
    return helpers


def _get_called_helper_names(func_node: ast.FunctionDef) -> set[str]:
    """Extract names of functions called directly within a function body."""
    names: set[str] = set()
    for node in ast.walk(func_node):
        if not isinstance(node, ast.Call):
            continue
        if isinstance(node.func, ast.Name):
            names.add(node.func.id)
    return names


def _nodes_to_scan(
    func_node: ast.FunctionDef, helpers: dict[str, ast.FunctionDef]
) -> list[ast.FunctionDef]:
    """Return the function itself plus any helpers it calls (one level deep)."""
    nodes = [func_node]
    for name in _get_called_helper_names(func_node):
        if name in helpers:
            nodes.append(helpers[name])
    return nodes


def _find_tests_with_persist_check(backend_path: Path) -> set[str]:
    """
    Find URL constants that have at least one test with a persistence check.

    A persistence check is a test function (including helpers it calls) that:
    1. Uses a write method (.post/.patch/.put/.delete) with the URL constant
    2. Also calls .get( to verify the change persisted
    """
    covered: set[str] = set()

    for filepath in backend_path.rglob("test_*.py"):
        try:
            source = filepath.read_text(encoding="utf-8")
            tree = ast.parse(source, filename=str(filepath))
        except SyntaxError:
            continue

        # Collect URL constants imported from urls module
        imported_urls: dict[str, str] = {}
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module and "urls" in node.module:
                for alias in node.names:
                    imported_urls[alias.name] = alias.asname or alias.name

        if not imported_urls:
            continue

        helpers = _build_helper_map(tree)

        # Check each test function
        for node in ast.walk(tree):
            if not isinstance(node, ast.FunctionDef) or not node.name.startswith("test_"):
                continue

            scan_nodes = _nodes_to_scan(node, helpers)

            write_url_constants: set[str] = set()
            for scan_node in scan_nodes:
                write_url_constants.update(
                    _extract_write_url_constants(scan_node, imported_urls)
                )
            if not write_url_constants:
                continue

            has_get = any(_has_get_call(n) for n in scan_nodes)
            if has_get:
                covered.update(write_url_constants)

    return covered


def _extract_write_url_constants(
    func_node: ast.FunctionDef, imported_urls: dict[str, str]
) -> set[str]:
    """
    Find URL constants used in write method calls within a function.
    Matches patterns like: client.post(URL_CONST, ...) or client.post(URL_CONST.format(...))
    """
    url_constants: set[str] = set()
    local_to_import = {local: original for original, local in imported_urls.items()}

    for node in ast.walk(func_node):
        if not isinstance(node, ast.Call):
            continue
        if not isinstance(node.func, ast.Attribute):
            continue
        if node.func.attr not in _WRITE_METHODS:
            continue
        if not node.args:
            continue

        first_arg = node.args[0]
        name = _extract_url_name(first_arg)
        if name and name in local_to_import:
            url_constants.add(local_to_import[name])
        elif name and name in imported_urls:
            url_constants.add(name)

    return url_constants


def _extract_url_name(node: ast.expr) -> str | None:
    """Extract the URL constant name from a call argument (NAME or NAME.format(...))."""
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
        if node.func.attr == "format" and isinstance(node.func.value, ast.Name):
            return node.func.value.id
    return None


def _has_get_call(func_node: ast.FunctionDef) -> bool:
    """
    Check if a function contains a .get( call, indicating a
    re-fetch for persistence verification.
    """
    for node in ast.walk(func_node):
        if not isinstance(node, ast.Call):
            continue
        if isinstance(node.func, ast.Attribute) and node.func.attr == "get":
            return True
    return False


def check_all(backend_path: Path) -> list[str]:
    """
    Check that every write endpoint has at least one test with a persistence check.
    """
    write_urls = _collect_write_endpoint_urls(backend_path)
    covered = _find_tests_with_persist_check(backend_path)

    errors: list[str] = []
    for constant_name, location in sorted(write_urls.items()):
        if constant_name not in covered:
            errors.append(
                f"{location}: Write endpoint using {constant_name} has no persistence test "
                f"(no test calls the write method and then .get() to verify)"
            )

    return errors


def main() -> None:
    backend = Path("backend")
    if len(sys.argv) > 1:
        pass
    errors = check_all(backend)
    for error in errors:
        print(error)  # noqa: T201  # linter output
    sys.exit(1 if errors else 0)


if __name__ == "__main__":
    main()
