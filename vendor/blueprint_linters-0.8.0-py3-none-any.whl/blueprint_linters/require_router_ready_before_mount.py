"""
SSR/SSG Vue apps must await router.isReady() before app.mount().

Without this, the client-side router hasn't resolved the initial route
when Vue hydrates. Router-link-active classes in the pre-rendered HTML
don't match the client state, causing Vue to patch the DOM and trigger
layout shifts (CLS ~0.336).

Measured impact: CLS -99% (0.336 → 0.004).
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

_SSR_INDICATOR = re.compile(r"createSSRApp|ssr:\s*true")
_APP_MOUNT = re.compile(r"app\.mount\s*\(")
_ROUTER_IS_READY = re.compile(r"router\.isReady\s*\(\s*\)")


def check_all(scan_path: Path) -> list[str]:
    """Check that SSR/SSG apps call router.isReady() before app.mount()."""
    errors: list[str] = []

    for filename in ("main.ts", "main.js"):
        entry_file = scan_path / "src" / filename
        if not entry_file.exists():
            continue

        content = entry_file.read_text(encoding="utf-8")

        if not _SSR_INDICATOR.search(content):
            continue

        mount_match = _APP_MOUNT.search(content)
        if not mount_match:
            continue

        ready_match = _ROUTER_IS_READY.search(content)
        if ready_match is None or ready_match.start() > mount_match.start():
            errors.append(
                f"{entry_file}: SSR app calls app.mount() without await router.isReady(). "
                f"This causes hydration mismatches and CLS ~0.3. "
                f"Add: router.isReady().then(() => app.mount(\"#app\"))"
            )

    return errors


def main() -> None:
    scan_path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("frontend")
    errors = check_all(scan_path)
    for error in errors:
        print(error)  # noqa: T201  # linter output
    sys.exit(1 if errors else 0)


if __name__ == "__main__":
    main()
