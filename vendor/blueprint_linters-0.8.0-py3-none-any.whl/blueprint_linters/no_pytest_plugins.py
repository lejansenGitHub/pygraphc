#!/usr/bin/env python3
"""
Ban pytest_plugins variable in conftest.py files.
Fixtures must be imported explicitly — pytest_plugins bypasses linters.
"""

from __future__ import annotations

import ast
import sys
from pathlib import Path

from blueprint_linters.common import check_files


def check_file(filepath: Path, tree: ast.Module) -> list[str]:
    errors: list[str] = []
    if filepath.name != "conftest.py":
        return errors

    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == "pytest_plugins":
                    errors.append(
                        f"{filepath}:{node.lineno}: "
                        f"pytest_plugins variable in conftest.py. "
                        f"Import fixtures explicitly instead."
                    )
    return errors


def main() -> None:
    sys.exit(check_files(check_file, "no pytest_plugins"))


if __name__ == "__main__":
    main()
