#!/usr/bin/env python3
"""
Files in test_support/ must follow naming conventions:
*_factory.py, *_cases.py, *_mock.py, *_fixtures.py.
Subdirectories (factories/, cases/, mocks/, fixtures/) are allowed.
"""

from __future__ import annotations

import sys
from pathlib import Path

VALID_SUFFIXES = ("_factory.py", "_cases.py", "_mock.py", "_fixtures.py")
VALID_SUBDIRS = {"factories", "cases", "mocks", "fixtures", "python", "db", "db_persistent"}


def check_file(filepath: Path) -> list[str]:
    errors: list[str] = []
    parts = filepath.parts

    if "test_support" not in parts:
        return errors
    if filepath.name == "__init__.py":
        return errors

    # Check if file is in a valid subdirectory
    test_support_idx = parts.index("test_support")
    remaining = parts[test_support_idx + 1 :]
    if len(remaining) >= 2:
        subdirectory = remaining[0]
        if subdirectory in VALID_SUBDIRS:
            return errors

    # Check file naming
    if not any(filepath.name.endswith(suffix) for suffix in VALID_SUFFIXES):
        errors.append(
            f"{filepath}:1: "
            f"File in test_support/ does not follow naming convention. "
            f"Must end with one of: {', '.join(VALID_SUFFIXES)}."
        )
    return errors


def main() -> int:
    errors: list[str] = []
    for filepath_str in sys.argv[1:]:
        filepath = Path(filepath_str)
        if filepath.suffix == ".py":
            errors.extend(check_file(filepath))
    for error in errors:
        print(error)  # noqa: T201  # linter output
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
