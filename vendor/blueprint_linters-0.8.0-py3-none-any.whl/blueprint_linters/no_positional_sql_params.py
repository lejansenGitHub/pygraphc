#!/usr/bin/env python3
"""
SQL queries must use named params %(name)s with dict input, not positional %s with tuples.

Named params are more readable and less error-prone — the param name documents
which value goes where, and reordering columns doesn't break the query.
"""

from __future__ import annotations

import ast
import re
import sys
from pathlib import Path

from blueprint_linters.common import check_files

_POSITIONAL_PARAM = re.compile(r"(?<!%)%s")
_NAMED_PARAM = re.compile(r"%\(\w+\)s")


def _has_positional_params(value: str) -> bool:
    """Check if a string contains positional %s params (not %(name)s)."""
    return bool(_POSITIONAL_PARAM.search(value))


def _looks_like_sql(value: str) -> bool:
    """Heuristic: string contains SQL keywords."""
    upper = value.upper()
    return any(keyword in upper for keyword in ("SELECT ", "INSERT ", "UPDATE ", "DELETE ", "WHERE ", "VALUES"))


def check_file(filepath: Path, tree: ast.Module) -> list[str]:
    """Reject positional %s params in SQL strings within backend code."""
    errors: list[str] = []

    if "tests" in filepath.parts:
        return errors
    if not str(filepath).startswith("backend"):
        return errors
    if "linter_scripts" in filepath.parts:
        return errors

    for node in ast.walk(tree):
        if not isinstance(node, ast.Constant) or not isinstance(node.value, str):
            continue
        value = node.value
        if _looks_like_sql(value) and _has_positional_params(value):
            errors.append(
                f"{filepath}:{node.lineno}: "
                f"Positional %s in SQL query. Use named params %(name)s with dict input instead."
            )

    return errors


def main() -> None:
    sys.exit(check_files(check_file, "no positional SQL params"))


if __name__ == "__main__":
    main()
