#!/usr/bin/env python3
"""
Ban direct SQLAlchemy imports in application code.
All DB access must go through SQLdataclass.
"""

from __future__ import annotations

import ast
import sys
from pathlib import Path

from blueprint_linters.common import check_files


def check_file(filepath: Path, tree: ast.Module) -> list[str]:
    """
    Reject `import sqlalchemy` and `from sqlalchemy` in files
    that are not part of the sqldataclass package itself.
    """
    errors: list[str] = []
    parts = filepath.parts
    if "sqldataclass" in parts:
        return errors
    # Also allow in the base/db repository module itself
    if "base" in parts and "db" in parts:
        return errors

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name == "sqlalchemy" or alias.name.startswith("sqlalchemy."):
                    errors.append(
                        f"{filepath}:{node.lineno}: Direct SQLAlchemy import. Use SQLdataclass instead."
                    )
        elif isinstance(node, ast.ImportFrom) and node.module is not None:
            if node.module == "sqlalchemy" or node.module.startswith("sqlalchemy."):
                errors.append(
                    f"{filepath}:{node.lineno}: Direct SQLAlchemy import. Use SQLdataclass instead."
                )
    return errors


def main() -> None:
    sys.exit(check_files(check_file, "ban direct SQLAlchemy imports"))


if __name__ == "__main__":
    main()
