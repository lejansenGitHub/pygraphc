#!/usr/bin/env python3
"""
Integration tests must be synchronous.

FastAPI's TestClient handles async internally. Using async def in
integration tests adds pytest-asyncio/anyio overhead (~200ms per test)
and causes event loop lifecycle issues with asyncpg pools.

Only e2e tests (Playwright, real browser) should be async.
"""

from __future__ import annotations

import ast
import sys
from pathlib import Path

from blueprint_linters.common import check_files


def _is_integration_test(filepath: Path) -> bool:
    return "integration_tests" in filepath.parts and filepath.name.startswith("test_")


def check_file(filepath: Path, tree: ast.Module) -> list[str]:
    errors: list[str] = []
    if not _is_integration_test(filepath):
        return errors

    for node in ast.walk(tree):
        if isinstance(node, ast.AsyncFunctionDef) and node.name.startswith("test_"):
            errors.append(
                f"{filepath}:{node.lineno}: "
                f"Async test function in integration_tests/: {node.name}. "
                f"Use sync TestClient instead. See project_design.md § Endpoint Testing."
            )
    return errors


def main() -> None:
    sys.exit(check_files(check_file, "no async integration tests"))


if __name__ == "__main__":
    main()
