#!/usr/bin/env python3
"""
Static assets must be served with Cache-Control headers.

Vite produces content-hashed filenames (e.g. index-DM4dzm7r.js) that are
immutable — a new deploy produces new filenames. Without Cache-Control:
immutable, browsers re-download them on every visit.

Scans the FastAPI app entrypoint (main.py) for Cache-Control string literals
in the static file serving code.
"""

from __future__ import annotations

import ast
import sys
from pathlib import Path

from blueprint_linters.common import check_files


def check_file(filepath: Path, tree: ast.Module) -> list[str]:
    """Check that main.py sets Cache-Control headers for static assets."""
    if filepath.name != "main.py":
        return []
    if "backend" not in str(filepath):
        return []

    has_static_files = False
    has_cache_control = False

    for node in ast.walk(tree):
        # Detect StaticFiles mount
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            if node.func.id == "StaticFiles":
                has_static_files = True

        # Detect Cache-Control string in any context
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            if "Cache-Control" in node.value or "max-age" in node.value or "immutable" in node.value:
                has_cache_control = True

    if has_static_files and not has_cache_control:
        return [
            f"{filepath}: StaticFiles mounted but no Cache-Control headers found. "
            f"Hashed assets should be served with: Cache-Control: public, max-age=31536000, immutable"
        ]

    return []


def main() -> None:
    sys.exit(check_files(check_file, "require cache headers for static assets"))


if __name__ == "__main__":
    main()
