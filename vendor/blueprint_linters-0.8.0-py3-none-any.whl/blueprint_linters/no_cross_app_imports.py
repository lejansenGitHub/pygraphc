#!/usr/bin/env python3
"""
Apps cannot import from each other.
If two apps need shared logic, it belongs in service/ or base/.
"""

from __future__ import annotations

import ast
import sys
from pathlib import Path

from blueprint_linters.common import check_files


def _get_app_name(filepath: Path) -> str | None:
    """
    Extract the app name from a file path like backend/app/orders/src/endpoints.py -> "orders".
    """
    parts = filepath.parts
    try:
        backend_idx = parts.index("backend")
    except ValueError:
        return None
    remaining = parts[backend_idx + 1 :]
    if len(remaining) >= 2 and remaining[0] == "app":
        return remaining[1]
    return None


def check_file(filepath: Path, tree: ast.Module) -> list[str]:
    """
    Reject imports from backend.app.<other_app> in app modules.
    """
    errors: list[str] = []
    own_app = _get_app_name(filepath)
    if own_app is None:
        return errors

    for node in ast.walk(tree):
        import_paths: list[str] = []

        if isinstance(node, ast.ImportFrom) and node.module is not None:
            import_paths.append(node.module)
        elif isinstance(node, ast.Import):
            import_paths.extend(alias.name for alias in node.names)

        for import_path in import_paths:
            parts = import_path.split(".")
            if len(parts) >= 3 and parts[0] == "backend" and parts[1] == "app":
                imported_app = parts[2]
                if imported_app != own_app:
                    errors.append(
                        f"{filepath}:{node.lineno}: "
                        f"Cross-app import: {own_app}/ cannot import from {imported_app}/. "
                        f"Move shared logic to service/ or base/."
                    )
    return errors


def main() -> None:
    sys.exit(check_files(check_file, "no cross-app imports"))


if __name__ == "__main__":
    main()
