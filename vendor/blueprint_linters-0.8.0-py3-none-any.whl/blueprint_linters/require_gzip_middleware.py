#!/usr/bin/env python3
"""
Webapp must have GZipMiddleware enabled.

Scans the FastAPI app entrypoint (main.py) for GZipMiddleware in the
middleware stack. Without it, JS/CSS/JSON responses are sent uncompressed,
adding ~400-500ms to every page load.
"""

from __future__ import annotations

import ast
import sys
from pathlib import Path

from blueprint_linters.common import check_files


def check_file(filepath: Path, tree: ast.Module) -> list[str]:
    """Check that main.py includes GZipMiddleware."""
    if filepath.name != "main.py":
        return []
    if "backend" not in str(filepath):
        return []

    for node in ast.walk(tree):
        # Pattern: app.add_middleware(GZipMiddleware, ...)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            if node.func.attr == "add_middleware" and node.args:
                first_arg = node.args[0]
                if isinstance(first_arg, ast.Name) and first_arg.id == "GZipMiddleware":
                    return []

    return [f"{filepath}: GZipMiddleware not found. Add: app.add_middleware(GZipMiddleware, minimum_size=500)"]


def main() -> None:
    sys.exit(check_files(check_file, "require GZip middleware"))


if __name__ == "__main__":
    main()
