#!/usr/bin/env python3
"""
Verify that the frontend API client follows a parseable structure.

Checks that cross-stack linters can reliably extract:
  - Interface names and their fields
  - API method names, HTTP methods, paths, and return types

Rules:
  1. Every api.get/post/patch/delete call must have an explicit type parameter
  2. Paths must be string literals (not variables or concatenation)
  3. Interfaces must not use 'any' type
  4. Every exported interface must have at least one field

This linter runs on TypeScript files (api.ts or api/*.ts).
"""

from __future__ import annotations

import re
import sys
from pathlib import Path


def check_api_client(filepath: Path) -> list[str]:
    """Check the API client file for structural violations."""
    if not filepath.name.endswith(".ts"):
        return []

    try:
        source = filepath.read_text(encoding="utf-8")
    except (FileNotFoundError, PermissionError):
        return []

    errors: list[str] = []
    lines = source.splitlines()

    for line_number, line in enumerate(lines, 1):
        stripped = line.strip()

        # Rule 1: api.get/post/patch/delete must have type parameter <Type>
        # Exception: delete calls and void operations (no assignment) are allowed without types
        api_call_match = re.search(r"api\.(get|post|patch|put|delete)\s*\(", stripped)
        if api_call_match:
            method = api_call_match.group(1)
            typed_match = re.search(r"api\.(get|post|patch|put|delete)\s*<[^>]+>\s*\(", stripped)
            if not typed_match and method != "delete":
                # Check if the call result is used (assigned or returned)
                has_assignment = re.search(r"(=>|=)\s*api\.", stripped)
                if has_assignment:
                    errors.append(
                        f"{filepath}:{line_number}: API call without return type. "
                        f"Use api.{method}<ReturnType>(...) for cross-stack linting."
                    )

        # Rule 2: Paths must be string literals (single-quoted or template literals)
        typed_call = re.search(r"api\.\w+<[^>]+>\(\s*(.+)", stripped)
        if typed_call:
            first_arg = typed_call.group(1)
            # Should start with ' or ` (string literal or template literal)
            if not re.match(r"""^['"`]""", first_arg.strip()):
                errors.append(
                    f"{filepath}:{line_number}: API path must be a string literal, "
                    f"not a variable or expression."
                )

        # Rule 3: No 'any' in interface fields
        if re.match(r"\w+\s*[?]?\s*:\s*any\b", stripped):
            errors.append(
                f"{filepath}:{line_number}: Interface field uses 'any' type. "
                f"Use an explicit type for cross-stack linting."
            )

    return errors


def check_all(frontend_path: Path) -> list[str]:
    """
    Find and check the API client file(s).
    Looks for api.ts or api/index.ts in the frontend src directory.
    """
    errors: list[str] = []

    candidates = [
        frontend_path / "src" / "api.ts",
        frontend_path / "src" / "api" / "index.ts",
    ]

    # Also check all .ts files in api/ directory if it exists
    api_dir = frontend_path / "src" / "api"
    if api_dir.is_dir():
        for ts_file in api_dir.glob("*.ts"):
            if ts_file not in candidates:
                candidates.append(ts_file)

    found = False
    for candidate in candidates:
        if candidate.exists():
            found = True
            errors.extend(check_api_client(candidate))

    if not found:
        errors.append(
            f"No API client found at {frontend_path}/src/api.ts or {frontend_path}/src/api/index.ts. "
            f"Cross-stack linting requires a parseable API client."
        )

    return errors


def main() -> None:
    frontend = Path("frontend")
    if len(sys.argv) > 1:
        # Accept explicit path
        frontend = Path(sys.argv[1])
    errors = check_all(frontend)
    for error in errors:
        print(error)  # noqa: T201  # linter output
    sys.exit(1 if errors else 0)


if __name__ == "__main__":
    main()
