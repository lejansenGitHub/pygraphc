#!/usr/bin/env python3
"""
Ban direct _connection access outside of repository files.

_connection is single-underscore private on ReadRepository/WriteRepository.
Subclasses (in *_repository.py / repository.py) may access it freely.
All other code must go through repository methods.
"""

from __future__ import annotations

import ast
import sys
from pathlib import Path

from blueprint_linters.common import check_files

REPO_FILE_SUFFIXES = ("_repository.py", "repository.py")


def _is_repository_file(filepath: Path) -> bool:
    return any(filepath.name.endswith(suffix) for suffix in REPO_FILE_SUFFIXES)


def check_file(filepath: Path, tree: ast.Module) -> list[str]:
    errors: list[str] = []
    if _is_repository_file(filepath):
        return errors

    for node in ast.walk(tree):
        if isinstance(node, ast.Attribute) and node.attr == "_connection":
            errors.append(
                f"{filepath}:{node.lineno}: "
                f"Direct _connection access outside repository file. "
                f"Use repository methods instead."
            )
    return errors


def main() -> None:
    sys.exit(check_files(check_file, "no _connection outside repositories"))


if __name__ == "__main__":
    main()
