"""
Runtime performance gate: run Lighthouse and assert minimum scores.

Catches regressions that static linters cannot detect — bundle bloat,
missing srcset, eager third-party scripts, hydration mismatches, etc.

This linter shells out to ``npx lighthouse``. It is opt-in: when the
environment variable ``LIGHTHOUSE_URL`` is not set, the check passes
silently. The timeout defaults to 120 seconds and can be overridden
with ``LIGHTHOUSE_TIMEOUT``.

Default thresholds:
  Performance >= 90, LCP < 2500ms, FCP < 1800ms, CLS < 0.1, TBT < 200ms
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

_THRESHOLDS: dict[str, tuple[str, float, str]] = {
    # key: (json_path_in_audits, max_value, display_unit)
    "performance_score": ("", 0.9, ""),
    "largest-contentful-paint": ("numericValue", 2500, "ms"),
    "first-contentful-paint": ("numericValue", 1800, "ms"),
    "cumulative-layout-shift": ("numericValue", 0.1, ""),
    "total-blocking-time": ("numericValue", 200, "ms"),
}


def _parse_lighthouse_result(raw_json: str, url: str) -> list[str]:
    """Extract metrics from Lighthouse JSON and check against thresholds."""
    try:
        result = json.loads(raw_json)
    except json.JSONDecodeError as error:
        return [f"Lighthouse: Failed to parse JSON output: {error}. URL: {url}"]

    errors: list[str] = []
    lighthouse_result = result.get("lighthouseResult", result)

    performance_score = (
        lighthouse_result.get("categories", {}).get("performance", {}).get("score")
    )
    if performance_score is not None and performance_score < 0.9:
        errors.append(
            f"Lighthouse: Performance score {int(performance_score * 100)} "
            f"is below threshold 90. URL: {url}"
        )

    audits = lighthouse_result.get("audits", {})
    for audit_id, (value_key, threshold, unit) in _THRESHOLDS.items():
        if audit_id == "performance_score":
            continue
        audit = audits.get(audit_id, {})
        value = audit.get(value_key)
        if value is None:
            continue
        if value > threshold:
            display_value = f"{value:.0f}{unit}" if unit else f"{value:.3f}"
            display_threshold = f"{threshold:.0f}{unit}" if unit else f"{threshold}"
            errors.append(
                f"Lighthouse: {audit_id} {display_value} exceeds threshold "
                f"{display_threshold}. URL: {url}"
            )

    return errors


def check_all(scan_path: Path) -> list[str]:
    """Run Lighthouse against LIGHTHOUSE_URL and check performance thresholds."""
    url = os.environ.get("LIGHTHOUSE_URL")
    if not url:
        return []

    timeout = int(os.environ.get("LIGHTHOUSE_TIMEOUT", "120"))

    command = [
        "npx", "lighthouse", url,
        "--output=json",
        "--chrome-flags=--headless --no-sandbox",
        "--only-categories=performance",
        "--quiet",
    ]

    try:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except FileNotFoundError:
        return [f"Lighthouse: npx not found. Install Node.js to use this linter. URL: {url}"]
    except subprocess.TimeoutExpired:
        return [f"Lighthouse: Timed out after {timeout}s. URL: {url}"]

    if result.returncode != 0 and not result.stdout:
        return [
            f"Lighthouse: Failed to run audit (exit code {result.returncode}). "
            f"URL: {url}. stderr: {result.stderr[:200]}"
        ]

    return _parse_lighthouse_result(result.stdout, url)


def main() -> None:
    errors = check_all(Path("."))
    for error in errors:
        print(error)  # noqa: T201  # linter output
    sys.exit(1 if errors else 0)


if __name__ == "__main__":
    main()
