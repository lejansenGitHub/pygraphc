#!/usr/bin/env python3
"""
Unit tests must not access the database directly.

TestClient is allowed (for endpoint format/conversion tests with mocked services).
Direct DB access (psycopg, asyncpg, get_db, get_pool, _connection) is banned.
"""

from __future__ import annotations

import ast
import sys
from pathlib import Path

from blueprint_linters.common import check_files

BANNED_MODULES = {"psycopg", "asyncpg"}
BANNED_ATTRS = {"get_db", "get_pool", "init_db", "release_db", "_connection"}


def _is_unit_test(filepath: Path) -> bool:
    return "unit_tests" in filepath.parts


def check_file(filepath: Path, tree: ast.Module) -> list[str]:
    errors: list[str] = []
    if not _is_unit_test(filepath):
        return errors

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name in BANNED_MODULES or alias.name.split(".")[0] in BANNED_MODULES:
                    errors.append(
                        f"{filepath}:{node.lineno}: "
                        f"DB import in unit test: {alias.name}. "
                        f"Unit tests must not access the database."
                    )
        elif isinstance(node, ast.ImportFrom) and node.module is not None:
            if node.module in BANNED_MODULES or node.module.split(".")[0] in BANNED_MODULES:
                errors.append(
                    f"{filepath}:{node.lineno}: "
                    f"DB import in unit test: {node.module}. "
                    f"Unit tests must not access the database."
                )
            for alias in node.names:
                if alias.name in BANNED_ATTRS:
                    errors.append(
                        f"{filepath}:{node.lineno}: "
                        f"DB access function in unit test: {alias.name}. "
                        f"Unit tests must not access the database."
                    )
    return errors


def main() -> None:
    sys.exit(check_files(check_file, "no DB in unit tests"))


if __name__ == "__main__":
    main()
