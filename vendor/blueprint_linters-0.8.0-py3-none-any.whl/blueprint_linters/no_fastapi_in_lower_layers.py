#!/usr/bin/env python3
"""
No FastAPI imports in base/ or service/ layers.
FastAPI lives only in app/. Lower layers are framework-agnostic.
"""

from __future__ import annotations

import ast
import sys
from pathlib import Path

from blueprint_linters.common import check_files


def _is_lower_layer(filepath: Path) -> bool:
    """
    Check if file is in backend/base/ or backend/service/.
    """
    parts = filepath.parts
    try:
        backend_idx = parts.index("backend")
    except ValueError:
        return False
    if backend_idx + 1 < len(parts):
        layer = parts[backend_idx + 1]
        return layer in ("base", "service")
    return False


def check_file(filepath: Path, tree: ast.Module) -> list[str]:
    """
    Reject FastAPI imports in base/ and service/ layers.
    """
    errors: list[str] = []
    if not _is_lower_layer(filepath):
        return errors

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name == "fastapi" or alias.name.startswith("fastapi."):
                    errors.append(
                        f"{filepath}:{node.lineno}: "
                        f"FastAPI import in lower layer. FastAPI is only allowed in app/."
                    )
        elif isinstance(node, ast.ImportFrom) and node.module is not None:
            if node.module == "fastapi" or node.module.startswith("fastapi."):
                errors.append(
                    f"{filepath}:{node.lineno}: "
                    f"FastAPI import in lower layer. FastAPI is only allowed in app/."
                )
    return errors


def main() -> None:
    sys.exit(check_files(check_file, "no FastAPI in lower layers"))


if __name__ == "__main__":
    main()
