"""
External font CDN links are render-blocking.

Loading fonts from Google Fonts or similar CDNs adds 2 DNS lookups plus
a render-blocking CSS fetch before any text is visible. Self-hosting
fonts with @font-face and font-display: swap eliminates this entirely.

Measured impact: FCP -56% (3.4s → 1.5s).
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

_FONT_CDN_PATTERN = re.compile(
    r"(fonts\.googleapis\.com|fonts\.gstatic\.com|fonts\.bunny\.net|use\.typekit\.net)"
)


def check_all(scan_path: Path) -> list[str]:
    """Check that index.html does not reference external font CDNs."""
    errors: list[str] = []

    for index_html in sorted(scan_path.rglob("index.html")):
        if "node_modules" in str(index_html):
            continue
        content = index_html.read_text(encoding="utf-8")
        for match in _FONT_CDN_PATTERN.finditer(content):
            domain = match.group(1)
            errors.append(
                f"{index_html}: External font CDN link detected ({domain}). "
                f"Self-host fonts with @font-face and font-display: swap instead."
            )

    return errors


def main() -> None:
    scan_path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("frontend")
    errors = check_all(scan_path)
    for error in errors:
        print(error)  # noqa: T201  # linter output
    sys.exit(1 if errors else 0)


if __name__ == "__main__":
    main()
