#!/usr/bin/env python3
"""
Enforce the blueprint folder structure for backend modules.

Every module under backend/{base,service,app}/ must have:
  - src/       (implementation)
  - exports/   (public API for other modules)
  - tests/     (test directory)

Optional subdirectories under exports/:
  - exports/types/     (type-only exports)
  - exports/services/  (functional exports)

Optional subdirectories under tests/:
  - tests/unit_tests/
  - tests/component_tests/
  - tests/integration_tests/
  - tests/test_support/

Reports missing required directories and unexpected files at the module root
(all code should be in src/, exports/, or tests/).
"""

from __future__ import annotations

import sys
from pathlib import Path

LAYERS = ("base", "service", "app")
REQUIRED_DIRS = {"src", "exports", "tests"}
ALLOWED_ROOT_FILES = {"__init__.py"}


def check_all(backend_path: Path) -> list[str]:
    """Check folder structure for all backend modules."""
    errors: list[str] = []

    if not backend_path.exists():
        return []

    for layer in LAYERS:
        layer_dir = backend_path / layer
        if not layer_dir.exists():
            continue

        for module_dir in sorted(layer_dir.iterdir()):
            if not module_dir.is_dir():
                continue
            if module_dir.name.startswith((".", "__")):
                continue

            # Check required directories
            for required in REQUIRED_DIRS:
                required_path = module_dir / required
                if not required_path.exists():
                    errors.append(
                        f"{module_dir.relative_to(backend_path.parent)}: "
                        f"missing required directory '{required}/'"
                    )

            # Check for unexpected files at module root (should be in src/)
            for item in sorted(module_dir.iterdir()):
                if item.is_file() and item.name not in ALLOWED_ROOT_FILES:
                    errors.append(
                        f"{item.relative_to(backend_path.parent)}: "
                        f"file at module root — move to src/ or exports/"
                    )

    return errors


def main() -> None:
    backend = Path("backend")
    if len(sys.argv) > 1:
        backend = Path(sys.argv[1])
    errors = check_all(backend)
    for error in errors:
        print(error)  # noqa: T201  # linter diagnostic output
    sys.exit(1 if errors else 0)


if __name__ == "__main__":
    main()
