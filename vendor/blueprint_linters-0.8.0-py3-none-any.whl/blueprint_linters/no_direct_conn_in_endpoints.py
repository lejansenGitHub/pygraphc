#!/usr/bin/env python3
"""
Endpoints must not depend on get_connection directly.

Use repo Depends() factories (from dependencies.py) and TransactionHandle
instead. Raw Connection access belongs in repos and service functions only.

Exceptions: *_tasks.py (Celery tasks create connections manually).
"""

from __future__ import annotations

import ast
import sys
from pathlib import Path

from blueprint_linters.common import check_files


def _is_endpoint_file(filepath: Path) -> bool:
    """True for *_endpoints.py files in app/ (not tasks, not tests)."""
    name = filepath.name
    if "tests" in filepath.parts:
        return False
    if name.endswith("_tasks.py") or name == "tasks.py":
        return False
    return name.endswith("_endpoints.py") or name == "endpoints.py"


def check_file(filepath: Path, tree: ast.Module) -> list[str]:
    """Reject direct get_connection imports in endpoint files."""
    errors: list[str] = []

    if not _is_endpoint_file(filepath):
        return errors

    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module is not None:
            for alias in node.names:
                if alias.name == "get_connection":
                    errors.append(
                        f"{filepath}:{node.lineno}: "
                        f"Direct get_connection import in endpoint file. "
                        f"Use repo Depends() factories from dependencies.py and TransactionHandle instead."
                    )

    return errors


def main() -> None:
    sys.exit(check_files(check_file, "no direct conn in endpoints"))


if __name__ == "__main__":
    main()
