"""Tests for frontend performance linters."""

import json
import tempfile
from pathlib import Path

from blueprint_linters.require_self_hosted_fonts import check_all as check_fonts_cdn
from blueprint_linters.require_font_display_swap import check_all as check_font_display
from blueprint_linters.require_router_ready_before_mount import check_all as check_router_ready
from blueprint_linters.require_lighthouse_scores import _parse_lighthouse_result


def _setup(tmp: str, files: dict[str, str]) -> Path:
    """Create a temporary directory structure with the given files."""
    root = Path(tmp)
    for relative_path, content in files.items():
        filepath = root / relative_path
        filepath.parent.mkdir(parents=True, exist_ok=True)
        filepath.write_text(content, encoding="utf-8")
    return root


# --- require_self_hosted_fonts ---


def test_google_fonts_link_detected() -> None:
    """An index.html referencing Google Fonts CDN is a violation."""
    with tempfile.TemporaryDirectory() as tmp:
        root = _setup(tmp, {
            "index.html": '<link href="https://fonts.googleapis.com/css2?family=Lato" rel="stylesheet" />',
        })
        errors = check_fonts_cdn(root)
        assert len(errors) == 1
        assert "fonts.googleapis.com" in errors[0]


def test_self_hosted_fonts_passes() -> None:
    """An index.html with only local font references passes."""
    with tempfile.TemporaryDirectory() as tmp:
        root = _setup(tmp, {
            "index.html": '<link rel="stylesheet" href="/assets/style.css" />',
        })
        errors = check_fonts_cdn(root)
        assert errors == []


def test_multiple_cdn_links_detected() -> None:
    """Each CDN domain produces a separate error."""
    with tempfile.TemporaryDirectory() as tmp:
        root = _setup(tmp, {
            "index.html": (
                '<link href="https://fonts.googleapis.com/css2?family=Lato" />\n'
                '<link href="https://use.typekit.net/abc123.css" />\n'
            ),
        })
        errors = check_fonts_cdn(root)
        assert len(errors) == 2


def test_no_index_html_passes() -> None:
    """A project without index.html passes (e.g. API-only project)."""
    with tempfile.TemporaryDirectory() as tmp:
        errors = check_fonts_cdn(Path(tmp))
        assert errors == []


def test_import_url_in_style_tag_detected() -> None:
    """@import url() inside a <style> tag is also caught."""
    with tempfile.TemporaryDirectory() as tmp:
        root = _setup(tmp, {
            "index.html": "<style>@import url('https://fonts.googleapis.com/css2?family=Inter');</style>",
        })
        errors = check_fonts_cdn(root)
        assert len(errors) == 1


def test_node_modules_index_html_ignored() -> None:
    """index.html inside node_modules is not checked."""
    with tempfile.TemporaryDirectory() as tmp:
        root = _setup(tmp, {
            "node_modules/some-pkg/index.html": '<link href="https://fonts.googleapis.com/css" />',
        })
        errors = check_fonts_cdn(root)
        assert errors == []


# --- require_font_display_swap ---


def test_font_display_block_detected() -> None:
    """A @font-face rule with font-display: block is a violation."""
    with tempfile.TemporaryDirectory() as tmp:
        root = _setup(tmp, {
            "src/icons.css": '@font-face { font-family: "PrimeIcons"; font-display: block; src: url(icons.woff2); }',
        })
        errors = check_font_display(root)
        assert len(errors) == 1
        assert "PrimeIcons" in errors[0]
        assert "block" in errors[0]


def test_font_display_swap_passes() -> None:
    """A @font-face rule with font-display: swap passes."""
    with tempfile.TemporaryDirectory() as tmp:
        root = _setup(tmp, {
            "src/fonts.css": '@font-face { font-family: "Lato"; font-display: swap; src: url(lato.woff2); }',
        })
        errors = check_font_display(root)
        assert errors == []


def test_missing_font_display_detected() -> None:
    """A @font-face rule without any font-display is a violation."""
    with tempfile.TemporaryDirectory() as tmp:
        root = _setup(tmp, {
            "src/fonts.css": '@font-face { font-family: "Lato"; src: url(lato.woff2); }',
        })
        errors = check_font_display(root)
        assert len(errors) == 1
        assert "missing" in errors[0].lower()


def test_multiple_font_face_blocks_mixed() -> None:
    """Only blocks without swap are flagged, correct blocks pass."""
    with tempfile.TemporaryDirectory() as tmp:
        root = _setup(tmp, {
            "src/fonts.css": (
                '@font-face { font-family: "Good"; font-display: swap; src: url(good.woff2); }\n'
                '@font-face { font-family: "Bad"; font-display: block; src: url(bad.woff2); }\n'
            ),
        })
        errors = check_font_display(root)
        assert len(errors) == 1
        assert "Bad" in errors[0]


def test_no_css_files_passes() -> None:
    """A project without CSS files passes."""
    with tempfile.TemporaryDirectory() as tmp:
        root = _setup(tmp, {"src/main.ts": "console.log('hello');"})
        errors = check_font_display(root)
        assert errors == []


def test_no_src_directory_passes() -> None:
    """A project without src/ directory passes."""
    with tempfile.TemporaryDirectory() as tmp:
        errors = check_font_display(Path(tmp))
        assert errors == []


# --- require_router_ready_before_mount ---


def test_ssr_app_without_router_ready_detected() -> None:
    """An SSR app that mounts without router.isReady() is a violation."""
    with tempfile.TemporaryDirectory() as tmp:
        root = _setup(tmp, {
            "src/main.ts": (
                'const { app } = createAppInstance({ ssr: true, router });\n'
                'app.mount("#app");\n'
            ),
        })
        errors = check_router_ready(root)
        assert len(errors) == 1
        assert "router.isReady()" in errors[0]


def test_ssr_app_with_router_ready_passes() -> None:
    """An SSR app that awaits router.isReady() before mount passes."""
    with tempfile.TemporaryDirectory() as tmp:
        root = _setup(tmp, {
            "src/main.ts": (
                'const { app } = createAppInstance({ ssr: true, router });\n'
                'router.isReady().then(() => {\n'
                '  app.mount("#app");\n'
                '});\n'
            ),
        })
        errors = check_router_ready(root)
        assert errors == []


def test_non_ssr_app_skipped() -> None:
    """A non-SSR app (regular createApp) is not checked."""
    with tempfile.TemporaryDirectory() as tmp:
        root = _setup(tmp, {
            "src/main.ts": (
                'const app = createApp(App);\n'
                'app.mount("#app");\n'
            ),
        })
        errors = check_router_ready(root)
        assert errors == []


def test_no_main_ts_passes() -> None:
    """A project without main.ts passes."""
    with tempfile.TemporaryDirectory() as tmp:
        root = _setup(tmp, {"src/index.ts": "export {};"})
        errors = check_router_ready(root)
        assert errors == []


def test_create_ssr_app_without_router_ready_detected() -> None:
    """createSSRApp without router.isReady() is a violation."""
    with tempfile.TemporaryDirectory() as tmp:
        root = _setup(tmp, {
            "src/main.ts": (
                'const app = createSSRApp(App);\n'
                'app.mount("#app");\n'
            ),
        })
        errors = check_router_ready(root)
        assert len(errors) == 1


# --- require_lighthouse_scores ---


def _lighthouse_json(
    score: float = 1.0,
    lcp: float = 1000,
    fcp: float = 800,
    cls: float = 0.01,
    tbt: float = 50,
) -> str:
    """Build a minimal Lighthouse JSON result."""
    return json.dumps({
        "categories": {"performance": {"score": score}},
        "audits": {
            "largest-contentful-paint": {"numericValue": lcp},
            "first-contentful-paint": {"numericValue": fcp},
            "cumulative-layout-shift": {"numericValue": cls},
            "total-blocking-time": {"numericValue": tbt},
        },
    })


def test_all_metrics_passing() -> None:
    """All metrics within thresholds produces no errors."""
    errors = _parse_lighthouse_result(_lighthouse_json(), "http://example.com")
    assert errors == []


def test_performance_score_below_threshold() -> None:
    """A performance score below 90 is flagged."""
    errors = _parse_lighthouse_result(
        _lighthouse_json(score=0.75), "http://example.com"
    )
    assert len(errors) == 1
    assert "below threshold 90" in errors[0]
    assert "75" in errors[0]


def test_lcp_above_threshold() -> None:
    """LCP above 2500ms is flagged."""
    errors = _parse_lighthouse_result(
        _lighthouse_json(lcp=3000), "http://example.com"
    )
    assert any("largest-contentful-paint" in error for error in errors)


def test_cls_above_threshold() -> None:
    """CLS above 0.1 is flagged."""
    errors = _parse_lighthouse_result(
        _lighthouse_json(cls=0.25), "http://example.com"
    )
    assert any("cumulative-layout-shift" in error for error in errors)


def test_multiple_metric_failures() -> None:
    """Multiple failing metrics each produce their own error."""
    errors = _parse_lighthouse_result(
        _lighthouse_json(score=0.5, lcp=5000, cls=0.5), "http://example.com"
    )
    assert len(errors) == 3


def test_malformed_json_handled() -> None:
    """Malformed JSON produces a single descriptive error."""
    errors = _parse_lighthouse_result("not json", "http://example.com")
    assert len(errors) == 1
    assert "Failed to parse" in errors[0]


def test_url_included_in_error_messages() -> None:
    """Every error message includes the tested URL."""
    errors = _parse_lighthouse_result(
        _lighthouse_json(score=0.5), "https://my-app.example.com"
    )
    assert all("https://my-app.example.com" in error for error in errors)
