"""Tests for the folder structure linter."""

from __future__ import annotations

import tempfile
from pathlib import Path

from blueprint_linters.enforce_folder_structure import check_all


def _make_module(tmp: Path, layer: str, name: str, dirs: list[str]) -> None:
    """Create a module with the specified directories."""
    module = tmp / "backend" / layer / name
    module.mkdir(parents=True, exist_ok=True)
    (module / "__init__.py").touch()
    for d in dirs:
        (module / d).mkdir(parents=True, exist_ok=True)
        (module / d / "__init__.py").touch()


def test_complete_module_passes() -> None:
    """A module with src/, exports/, and tests/ passes."""
    with tempfile.TemporaryDirectory() as tmp:
        _make_module(Path(tmp), "service", "orders", ["src", "exports", "tests"])
        errors = check_all(Path(tmp) / "backend")
        assert errors == []


def test_missing_src_rejected() -> None:
    """A module without src/ is a violation."""
    with tempfile.TemporaryDirectory() as tmp:
        _make_module(Path(tmp), "service", "orders", ["exports", "tests"])
        errors = check_all(Path(tmp) / "backend")
        assert len(errors) == 1
        assert "src/" in errors[0]


def test_missing_exports_rejected() -> None:
    """A module without exports/ is a violation."""
    with tempfile.TemporaryDirectory() as tmp:
        _make_module(Path(tmp), "service", "orders", ["src", "tests"])
        errors = check_all(Path(tmp) / "backend")
        assert len(errors) == 1
        assert "exports/" in errors[0]


def test_missing_tests_rejected() -> None:
    """A module without tests/ is a violation."""
    with tempfile.TemporaryDirectory() as tmp:
        _make_module(Path(tmp), "service", "orders", ["src", "exports"])
        errors = check_all(Path(tmp) / "backend")
        assert len(errors) == 1
        assert "tests/" in errors[0]


def test_file_at_module_root_rejected() -> None:
    """Files at the module root (not in src/exports/tests) are violations."""
    with tempfile.TemporaryDirectory() as tmp:
        _make_module(Path(tmp), "service", "orders", ["src", "exports", "tests"])
        (Path(tmp) / "backend" / "service" / "orders" / "utils.py").touch()
        errors = check_all(Path(tmp) / "backend")
        assert len(errors) == 1
        assert "utils.py" in errors[0]
        assert "module root" in errors[0]


def test_init_at_module_root_allowed() -> None:
    """__init__.py at the module root is fine."""
    with tempfile.TemporaryDirectory() as tmp:
        _make_module(Path(tmp), "service", "orders", ["src", "exports", "tests"])
        errors = check_all(Path(tmp) / "backend")
        assert errors == []


def test_all_layers_checked() -> None:
    """Modules in base/, service/, and app/ are all checked."""
    with tempfile.TemporaryDirectory() as tmp:
        _make_module(Path(tmp), "base", "db", ["src"])  # missing exports + tests
        _make_module(Path(tmp), "service", "orders", ["exports"])  # missing src + tests
        _make_module(Path(tmp), "app", "api", ["tests"])  # missing src + exports
        errors = check_all(Path(tmp) / "backend")
        assert len(errors) == 6  # 2 missing per module


def test_no_backend_returns_empty() -> None:
    """If backend/ doesn't exist, no errors."""
    errors = check_all(Path("/nonexistent/backend"))
    assert errors == []
