#!/usr/bin/env python3
"""
.commit() calls are only allowed in endpoint and Celery task files (backend/app/).
If a function in service/ genuinely needs to commit, its docstring must explain why.
"""

from __future__ import annotations

import ast
import sys
from pathlib import Path

from blueprint_linters.common import check_files


def _is_commit_allowed(filepath: Path) -> bool:
    """
    .commit() is only allowed in *_endpoints.py, *_tasks.py, and test files.
    """
    name = filepath.name
    if name.endswith("_endpoints.py") or name == "endpoints.py":
        return True
    if name.endswith("_tasks.py") or name == "tasks.py":
        return True
    if "tests" in filepath.parts:
        return True
    return False


def check_file(filepath: Path, tree: ast.Module) -> list[str]:
    """
    Reject .commit() calls outside endpoint and task files.
    """
    errors: list[str] = []
    if _is_commit_allowed(filepath):
        return errors

    for node in ast.walk(tree):
        if (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Attribute)
            and node.func.attr == "commit"
        ):
            errors.append(
                f"{filepath}:{node.lineno}: "
                f".commit() call outside app layer. "
                f"Commits belong in endpoints and Celery tasks only."
            )
    return errors


def main() -> None:
    sys.exit(check_files(check_file, "no deep commits"))


if __name__ == "__main__":
    main()
